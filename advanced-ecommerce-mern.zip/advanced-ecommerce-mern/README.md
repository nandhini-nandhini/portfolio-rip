# Advanced E-Commerce Management Platform (MERN)

This is a learning/demo starter project based on the features listed in your resume. It is newly written example code, not a recovery of your original source code.

## What you need
- Node.js 20 or newer
- MongoDB Community Server running locally, or a MongoDB Atlas connection string
- VS Code

## Folder structure
```
advanced-ecommerce-mern/
  server/
    src/
      middleware/auth.js
      models/{User,Product,Order}.js
      routes/{auth,products,orders}.js
      index.js
      seed.js
    .env.example
    package.json
  client/
    src/
      components/{Navbar,ProductCard}.jsx
      context/ShopContext.jsx
      pages/{Home,Login,Register,Cart,Orders}.jsx
      api.js
      App.jsx
      main.jsx
      styles.css
    index.html
    package.json
    vite.config.js
```

## Start the backend
1. Open this folder in VS Code.
2. Open terminal: **Terminal → New Terminal**.
3. Run `cd server`
4. Run `npm install`
5. Copy `.env.example` to `.env`, then update `MONGODB_URI` and `JWT_SECRET`.
6. Run `npm run dev`
7. In a second terminal, run `cd server` then `npm run seed` to add sample products.

## Start the frontend
1. Open another terminal in VS Code.
2. Run `cd client`
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL Vite prints, normally http://localhost:5173

Keep both terminals running while you use the app.

## API
- GET `/api/health`
- GET `/api/products?search=&category=`
- GET `/api/products/:id`
- POST `/api/products` (admin)
- PUT `/api/products/:id` (admin)
- DELETE `/api/products/:id` (admin)
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/auth/me` (login required)
- POST `/api/orders` (login required; demo checkout)
- GET `/api/orders/my` (login required)

## Make an admin
Register in the app first. In MongoDB Shell, select database `advanced_ecommerce` and run:
```
db.users.updateOne(
  { email: "your-email@example.com" },
  { $set: { role: "admin" } }
)
```

## Important
Checkout only records a demo order. It does not collect money or connect to a real payment provider. Do not deploy this demo as a production store without additional security, validation, testing, and a real payment provider.
