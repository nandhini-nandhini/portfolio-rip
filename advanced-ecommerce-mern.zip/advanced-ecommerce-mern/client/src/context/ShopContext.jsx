import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { api } from "../api";

const ShopContext = createContext(null);
export function ShopProvider({ children }) {
  const [cart, setCart] = useState(() => {
    try { return JSON.parse(localStorage.getItem("shop_cart") || "[]"); } catch { return []; }
  });
  const [wishlist, setWishlist] = useState(() => {
    try { return JSON.parse(localStorage.getItem("shop_wishlist") || "[]"); } catch { return []; }
  });
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("shop_user") || "null"); } catch { return null; }
  });

  useEffect(() => { localStorage.setItem("shop_cart", JSON.stringify(cart)); }, [cart]);
  useEffect(() => { localStorage.setItem("shop_wishlist", JSON.stringify(wishlist)); }, [wishlist]);

  function saveSession(data) {
    localStorage.setItem("shop_token", data.token);
    localStorage.setItem("shop_user", JSON.stringify(data.user));
    setUser(data.user);
  }
  function logout() {
    localStorage.removeItem("shop_token");
    localStorage.removeItem("shop_user");
    setUser(null);
  }
  function addToCart(product) {
    setCart((old) => {
      const found = old.find((item) => item._id === product._id);
      return found
        ? old.map((item) => item._id === product._id ? { ...item, quantity: Math.min(item.quantity + 1, product.stock || 99) } : item)
        : [...old, { ...product, quantity: 1 }];
    });
  }
  function updateQuantity(id, quantity) {
    if (quantity < 1) return;
    setCart((old) => old.map((item) => item._id === id ? { ...item, quantity: Math.min(quantity, item.stock || 99) } : item));
  }
  function removeFromCart(id) { setCart((old) => old.filter((item) => item._id !== id)); }
  function toggleWishlist(product) {
    setWishlist((old) => old.some((item) => item._id === product._id)
      ? old.filter((item) => item._id !== product._id)
      : [...old, product]);
  }
  function clearCart() { setCart([]); }

  const value = useMemo(() => ({
    cart, wishlist, user, saveSession, logout, addToCart, updateQuantity,
    removeFromCart, toggleWishlist, clearCart,
    cartCount: cart.reduce((sum, item) => sum + item.quantity, 0),
    cartTotal: cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
    api
  }), [cart, wishlist, user]);
  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>;
}
export function useShop() {
  const value = useContext(ShopContext);
  if (!value) throw new Error("useShop must be used inside ShopProvider");
  return value;
}
