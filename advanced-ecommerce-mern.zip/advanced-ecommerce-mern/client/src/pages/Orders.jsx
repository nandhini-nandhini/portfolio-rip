import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useShop } from "../context/ShopContext";

export default function Orders() {
  const { api, user } = useShop();
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState("");
  useEffect(() => { api("/orders/my").then((data) => setOrders(data.orders || [])).catch((err) => setError(err.message)); }, []);
  if (!user) return <main className="content-page"><h1 className="page-title">My orders</h1><p>Please <Link to="/login">sign in</Link> to view your orders.</p></main>;
  return <main className="content-page"><span className="eyebrow">ORDER HISTORY</span><h1 className="page-title">My orders</h1>{error && <p className="notice error">{error}</p>}{orders.length === 0 && !error ? <p className="notice">You haven't placed any orders yet.</p> : <div className="orders-list">{orders.map((order) => <article className="order-card" key={order._id}><div className="order-top"><div><span className="product-category">ORDER ID</span><strong>{order._id}</strong></div><span className="status-pill">{order.status}</span></div><div className="order-lines">{order.items.map((item, i) => <p key={`${item.product}-${i}`}>{item.name} × {item.quantity} <span>₹{(item.price * item.quantity).toLocaleString("en-IN")}</span></p>)}</div><div className="order-bottom"><span>{new Date(order.createdAt).toLocaleDateString("en-IN")}</span><strong>Total ₹{order.total.toLocaleString("en-IN")}</strong></div><small>Payment status: {order.paymentStatus} (demo)</small></article>)}</div>}</main>;
}
