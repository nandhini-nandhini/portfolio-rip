import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useShop } from "../context/ShopContext";

export function Login() {
  const { api, saveSession } = useShop();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault(); setError(""); setBusy(true);
    try { const data = await api("/auth/login", { method: "POST", body: JSON.stringify(form) }); saveSession(data); navigate(location.state?.from || "/"); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  return <main className="auth-page"><form className="auth-card" onSubmit={submit}><span className="eyebrow">WELCOME BACK</span><h1>Sign in</h1><p>Log in to view your orders and continue shopping.</p>{error && <div className="form-error">{error}</div>}<label>Email address<input type="email" required autoComplete="email" value={form.email} onChange={(e) => setForm({...form, email:e.target.value})}/></label><label>Password<input type="password" required autoComplete="current-password" value={form.password} onChange={(e) => setForm({...form, password:e.target.value})}/></label><button className="primary-button full-button" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button><div className="auth-switch">New here? <Link to="/register">Create an account</Link></div></form></main>;
}

export function Register() {
  const { api, saveSession } = useShop();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault(); setError(""); setBusy(true);
    try { const data = await api("/auth/register", { method: "POST", body: JSON.stringify(form) }); saveSession(data); navigate("/"); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  }
  return <main className="auth-page"><form className="auth-card" onSubmit={submit}><span className="eyebrow">JOIN SHOPSPHERE</span><h1>Create account</h1><p>Make an account to save your cart and place demo orders.</p>{error && <div className="form-error">{error}</div>}<label>Full name<input required maxLength="80" autoComplete="name" value={form.name} onChange={(e) => setForm({...form, name:e.target.value})}/></label><label>Email address<input type="email" required autoComplete="email" value={form.email} onChange={(e) => setForm({...form, email:e.target.value})}/></label><label>Password<input type="password" required minLength="8" autoComplete="new-password" value={form.password} onChange={(e) => setForm({...form, password:e.target.value})}/><small>At least 8 characters.</small></label><button className="primary-button full-button" disabled={busy}>{busy ? "Creating…" : "Create account"}</button><div className="auth-switch">Already registered? <Link to="/login">Sign in</Link></div></form></main>;
}
