import { useEffect, useMemo, useState } from "react";
import { Search, SlidersHorizontal, ArrowRight } from "lucide-react";
import { api } from "../api";
import ProductCard from "../components/ProductCard";
import { useShop } from "../context/ShopContext";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const { addToCart } = useShop();

  useEffect(() => {
    let active = true;
    setLoading(true);
    api("/products")
      .then((data) => { if (active) setProducts(data.products || []); })
      .catch((err) => { if (active) setError(err.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const categories = useMemo(() => ["All", ...new Set(products.map((p) => p.category))], [products]);
  const visible = useMemo(() => products.filter((p) => {
    const matchesCategory = category === "All" || p.category === category;
    const q = search.trim().toLowerCase();
    return matchesCategory && (!q || p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q));
  }), [products, search, category]);

  return (
    <main>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">YOUR EVERYDAY FINDS</span>
          <h1>Good things.<br/><em>Better living.</em></h1>
          <p>Thoughtfully picked essentials for your work, home and everyday adventures.</p>
          <a className="primary-button hero-button" href="#products">Explore collection <ArrowRight size={17}/></a>
        </div>
        <div className="hero-art">
          <img src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1100" alt="Modern retail store interior"/>
          <div className="hero-note"><span>THE NEW EDIT</span><strong>Find your next favourite.</strong></div>
        </div>
      </section>

      <section className="shop-section" id="products">
        <div className="section-heading"><div><span className="eyebrow">CURATED FOR YOU</span><h2>Shop the collection</h2></div><span className="result-count">{visible.length} products</span></div>
        <div className="filters">
          <label className="search-box"><Search size={18}/><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search products..."/></label>
          <label className="category-select"><SlidersHorizontal size={17}/><select value={category} onChange={(e) => setCategory(e.target.value)}>{categories.map((c) => <option key={c}>{c}</option>)}</select></label>
        </div>
        {loading && <p className="notice">Loading products…</p>}
        {error && <p className="notice error">{error}. Is the backend running, and have you seeded products?</p>}
        {!loading && !error && visible.length === 0 && <p className="notice">No products found. Try a different search.</p>}
        <div className="product-grid">{visible.map((product) => <ProductCard key={product._id} product={product}/>)}</div>
      </section>
      <section className="promo-strip"><div><span className="eyebrow">SHOP WITH EASE</span><h2>Your next favourite is waiting.</h2></div><a href="#products" className="text-link">Browse products <ArrowRight size={16}/></a></section>
    </main>
  );
}
