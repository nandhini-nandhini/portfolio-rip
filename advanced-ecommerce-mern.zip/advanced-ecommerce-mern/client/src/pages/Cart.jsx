import { Link, useNavigate } from "react-router-dom";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useState } from "react";
import { useShop } from "../context/ShopContext";

export function Cart() {
  const { cart, cartTotal, updateQuantity, removeFromCart, user, api, clearCart } = useShop();
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  async function checkout() {
    if (!user) return navigate("/login", { state: { from: "/cart" } });
    setBusy(true); setMessage("");
    try {
      const data = await api("/orders", { method: "POST", body: JSON.stringify({ items: cart.map((item) => ({ productId: item._id, quantity: item.quantity })) }) });
      clearCart(); setMessage(data.message || "Demo order placed successfully.");
    } catch (error) { setMessage(error.message); }
    finally { setBusy(false); }
  }
  if (cart.length === 0) return <main className="content-page empty-state"><ShoppingBag size={42}/><h1>Your cart is empty</h1><p>Explore the collection and add something you love.</p><Link className="primary-button" to="/">Start shopping</Link>{message && <p className="notice">{message}</p>}</main>;
  return <main className="content-page"><span className="eyebrow">YOUR SELECTION</span><h1 className="page-title">Shopping cart</h1>{message && <p className="notice">{message}</p>}<div className="cart-layout"><div className="cart-items">{cart.map((item) => <article className="cart-item" key={item._id}><img src={item.imageUrl || "https://placehold.co/160x160"} alt={item.name}/><div className="cart-item-info"><span className="product-category">{item.category}</span><h3>{item.name}</h3><strong>₹{item.price.toLocaleString("en-IN")}</strong><div className="quantity-control"><button aria-label="Decrease quantity" onClick={() => item.quantity === 1 ? removeFromCart(item._id) : updateQuantity(item._id, item.quantity - 1)}><Minus size={14}/></button><span>{item.quantity}</span><button aria-label="Increase quantity" disabled={item.quantity >= item.stock} onClick={() => updateQuantity(item._id, item.quantity + 1)}><Plus size={14}/></button></div></div><button className="remove-button" onClick={() => removeFromCart(item._id)} aria-label={`Remove ${item.name}`}><Trash2 size={17}/></button></article>)}</div><aside className="summary-card"><h2>Order summary</h2><div className="summary-line"><span>Subtotal</span><span>₹{cartTotal.toLocaleString("en-IN")}</span></div><div className="summary-line"><span>Shipping</span><span>Demo free</span></div><div className="summary-line total-line"><strong>Total</strong><strong>₹{cartTotal.toLocaleString("en-IN")}</strong></div><p className="summary-note">Demo checkout only. No payment will be collected.</p><button className="primary-button full-button" disabled={busy} onClick={checkout}>{busy ? "Placing order…" : "Place demo order"}</button><Link className="continue-link" to="/">Continue shopping</Link></aside></div></main>;
}

export function Wishlist() {
  const { wishlist, addToCart, toggleWishlist } = useShop();
  return <main className="content-page"><span className="eyebrow">SAVED ITEMS</span><h1 className="page-title">Your wishlist</h1>{wishlist.length === 0 ? <p className="notice">No saved products yet. Tap the heart on a product to save it.</p> : <div className="product-grid">{wishlist.map((p) => <article className="product-card" key={p._id}><div className="product-image-wrap"><img src={p.imageUrl} alt={p.name}/></div><div className="product-info"><span className="product-category">{p.category}</span><h3>{p.name}</h3><strong>₹{p.price.toLocaleString("en-IN")}</strong><div className="wishlist-actions"><button className="add-button" onClick={() => addToCart(p)}>Add to cart</button><button className="remove-wish" onClick={() => toggleWishlist(p)}>Remove</button></div></div></article>)}</div>}</main>;
}
