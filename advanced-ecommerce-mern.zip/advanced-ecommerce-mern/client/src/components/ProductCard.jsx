import { Heart, ShoppingCart } from "lucide-react";
import { useShop } from "../context/ShopContext";

export default function ProductCard({ product }) {
  const { addToCart, wishlist, toggleWishlist } = useShop();
  const liked = wishlist.some((item) => item._id === product._id);
  return (
    <article className="product-card">
      <div className="product-image-wrap">
        {product.featured && <span className="product-tag">Featured</span>}
        <button className={`heart-button ${liked ? "liked" : ""}`} onClick={() => toggleWishlist(product)} aria-label="Toggle wishlist"><Heart size={18} fill={liked ? "currentColor" : "none"}/></button>
        <img src={product.imageUrl || "https://placehold.co/600x400?text=Product"} alt={product.name} loading="lazy"/>
      </div>
      <div className="product-info">
        <span className="product-category">{product.category}</span>
        <h3>{product.name}</h3>
        <p>{product.description}</p>
        <div className="product-bottom"><strong>₹{product.price.toLocaleString("en-IN")}</strong><button className="add-button" disabled={product.stock < 1} onClick={() => addToCart(product)}><ShoppingCart size={16}/>{product.stock < 1 ? "Sold out" : "Add"}</button></div>
      </div>
    </article>
  );
}
