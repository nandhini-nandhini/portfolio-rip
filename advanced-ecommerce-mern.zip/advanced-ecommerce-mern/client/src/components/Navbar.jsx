import { Link, NavLink, useNavigate } from "react-router-dom";
import { ShoppingBag, Heart, UserRound, LogOut } from "lucide-react";
import { useShop } from "../context/ShopContext";

export default function Navbar() {
  const { cartCount, wishlist, user, logout } = useShop();
  const navigate = useNavigate();
  function handleLogout() { logout(); navigate("/"); }
  return (
    <header className="site-header">
      <div className="nav-wrap">
        <Link className="brand" to="/"><span className="brand-mark">S</span> ShopSphere</Link>
        <nav className="nav-links">
          <NavLink to="/">Shop</NavLink>
          {user && <NavLink to="/orders">My orders</NavLink>}
        </nav>
        <div className="nav-actions">
          <Link className="icon-link" to="/wishlist" aria-label="Wishlist"><Heart size={19}/><span>{wishlist.length}</span></Link>
          <Link className="icon-link" to="/cart" aria-label="Cart"><ShoppingBag size={19}/><span>{cartCount}</span></Link>
          {user ? <button className="nav-user" onClick={handleLogout} title="Log out"><LogOut size={17}/><span>Logout</span></button> : <Link className="nav-user" to="/login"><UserRound size={17}/><span>Login</span></Link>}
        </div>
      </div>
    </header>
  );
}
