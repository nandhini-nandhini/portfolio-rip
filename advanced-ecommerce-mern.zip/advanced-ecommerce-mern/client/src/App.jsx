import { BrowserRouter, Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import { Login, Register } from "./pages/Auth";
import { Cart, Wishlist } from "./pages/Cart";
import Orders from "./pages/Orders";
import { ShopProvider } from "./context/ShopContext";

function Footer() {
  return <footer className="site-footer"><div><strong>ShopSphere</strong><p>A MERN stack learning project.</p></div><span>Demo store · No real payments</span></footer>;
}
export default function App() {
  return <ShopProvider><BrowserRouter><Navbar/><Routes><Route path="/" element={<Home/>}/><Route path="/login" element={<Login/>}/><Route path="/register" element={<Register/>}/><Route path="/cart" element={<Cart/>}/><Route path="/wishlist" element={<Wishlist/>}/><Route path="/orders" element={<Orders/>}/><Route path="*" element={<main className="content-page"><h1>Page not found</h1></main>}/></Routes><Footer/></BrowserRouter></ShopProvider>;
}
