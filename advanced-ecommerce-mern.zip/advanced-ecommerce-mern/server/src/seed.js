import dotenv from "dotenv";
import mongoose from "mongoose";
import Product from "./models/Product.js";

dotenv.config();
const products = [
  { name: "Wireless Headphones", description: "Comfortable over-ear headphones for daily listening.", category: "Electronics", price: 2499, imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800", stock: 15, featured: true },
  { name: "Everyday Backpack", description: "A practical backpack for work, college and travel.", category: "Accessories", price: 1599, imageUrl: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800", stock: 20 },
  { name: "Running Shoes", description: "Lightweight shoes for everyday walks and runs.", category: "Fashion", price: 3299, imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800", stock: 12, featured: true },
  { name: "Smart Watch", description: "A simple smartwatch-style wearable for your daily routine.", category: "Electronics", price: 4999, imageUrl: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800", stock: 8 },
  { name: "Desk Lamp", description: "Minimal desk lamp for a home or study workspace.", category: "Home", price: 1199, imageUrl: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800", stock: 10 }
];

async function seed() {
  if (!process.env.MONGODB_URI) throw new Error("Set MONGODB_URI in server/.env first");
  await mongoose.connect(process.env.MONGODB_URI);
  await Product.deleteMany({});
  await Product.insertMany(products);
  console.log(`Inserted ${products.length} sample products.`);
  await mongoose.disconnect();
}
seed().catch(async (error) => {
  console.error(error);
  await mongoose.disconnect().catch(() => {});
  process.exit(1);
});
