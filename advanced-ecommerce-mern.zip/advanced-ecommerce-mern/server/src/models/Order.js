import mongoose from "mongoose";

const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  items: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
    name: { type: String, required: true },
    price: { type: Number, required: true, min: 0 },
    quantity: { type: Number, required: true, min: 1 }
  }],
  total: { type: Number, required: true, min: 0 },
  status: { type: String, enum: ["placed", "processing", "shipped", "delivered", "cancelled"], default: "placed" },
  paymentStatus: { type: String, enum: ["demo_pending", "paid", "failed"], default: "demo_pending" }
}, { timestamps: true });

export default mongoose.model("Order", orderSchema);
