import { Router } from "express";
import mongoose from "mongoose";
import Product from "../models/Product.js";
import { protect, adminOnly } from "../middleware/auth.js";

const router = Router();
const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

router.get("/", async (req, res, next) => {
  try {
    const { search = "", category = "" } = req.query;
    const filter = {};
    if (category && category !== "All") filter.category = category;
    if (search.trim()) {
      const safeSearch = escapeRegex(search.trim());
      filter.$or = [
        { name: { $regex: safeSearch, $options: "i" } },
        { description: { $regex: safeSearch, $options: "i" } }
      ];
    }
    const products = await Product.find(filter).sort({ createdAt: -1 }).limit(100);
    res.json({ products });
  } catch (error) { next(error); }
});

router.get("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid product id" });
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json({ product });
  } catch (error) { next(error); }
});

router.post("/", protect, adminOnly, async (req, res, next) => {
  try {
    const { name, description = "", category, price, imageUrl = "", stock = 0, featured = false } = req.body;
    if (!name?.trim() || !category?.trim() || !Number.isFinite(Number(price)) || Number(price) < 0) {
      return res.status(400).json({ message: "Valid name, category and non-negative price are required" });
    }
    const product = await Product.create({ name, description, category, price: Number(price), imageUrl, stock, featured });
    res.status(201).json({ product });
  } catch (error) { next(error); }
});

router.put("/:id", protect, adminOnly, async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid product id" });
    const allowed = ["name", "description", "category", "price", "imageUrl", "stock", "featured"];
    const updates = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key)));
    const product = await Product.findByIdAndUpdate(req.params.id, updates, { new: true, runValidators: true });
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json({ product });
  } catch (error) { next(error); }
});

router.delete("/:id", protect, adminOnly, async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid product id" });
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json({ message: "Product deleted" });
  } catch (error) { next(error); }
});

export default router;
