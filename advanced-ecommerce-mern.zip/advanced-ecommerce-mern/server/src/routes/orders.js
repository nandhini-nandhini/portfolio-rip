import { Router } from "express";
import mongoose from "mongoose";
import Product from "../models/Product.js";
import Order from "../models/Order.js";
import { protect } from "../middleware/auth.js";

const router = Router();

router.post("/", protect, async (req, res, next) => {
  try {
    const { items } = req.body;
    if (!Array.isArray(items) || items.length === 0) return res.status(400).json({ message: "Cart is empty" });
    if (items.some((item) => !mongoose.isValidObjectId(item.productId) || !Number.isInteger(Number(item.quantity)) || Number(item.quantity) < 1)) {
      return res.status(400).json({ message: "Each item needs a valid productId and positive integer quantity" });
    }

    const productIds = [...new Set(items.map((item) => item.productId))];
    const products = await Product.find({ _id: { $in: productIds } });
    const byId = new Map(products.map((product) => [product._id.toString(), product]));
    const orderItems = [];
    for (const item of items) {
      const product = byId.get(item.productId);
      const quantity = Number(item.quantity);
      if (!product) return res.status(400).json({ message: "A product in the cart no longer exists" });
      if (product.stock < quantity) return res.status(400).json({ message: `Not enough stock for ${product.name}` });
      orderItems.push({ product: product._id, name: product.name, price: product.price, quantity });
    }

    // Demo checkout: record order only; real payment and atomic stock updates are not implemented.
    const total = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const order = await Order.create({ user: req.user._id, items: orderItems, total });
    res.status(201).json({ order, message: "Demo order placed. No payment was charged." });
  } catch (error) { next(error); }
});

router.get("/my", protect, async (req, res, next) => {
  try {
    const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 });
    res.json({ orders });
  } catch (error) { next(error); }
});

export default router;
